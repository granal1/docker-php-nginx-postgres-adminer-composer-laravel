<?php

echo(phpinfo());